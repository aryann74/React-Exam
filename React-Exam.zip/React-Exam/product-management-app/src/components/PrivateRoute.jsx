// src/components/PrivateRoute.jsx

import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { useSelector } from 'react-redux';

const PrivateRoute = ({ component: Component, ...rest }) => {
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated); // Check if user is authenticated

  return (
    <Route
      {...rest}
      render={(props) =>
        isAuthenticated ? (
          <Component {...props} /> // Allow access if authenticated
        ) : (
          <Redirect to="/login" /> // Redirect to login page if not authenticated
        )
      }
    />
  );
};

export default PrivateRoute;
