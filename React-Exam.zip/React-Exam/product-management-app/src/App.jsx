// src/App.jsx

import React from 'react';
import { BrowserRouter as Router, Switch } from 'react-router-dom';
import { useSelector } from 'react-redux';
import Navbar from './components/Navbar';
import ProductList from './components/ProductList';
import ProductForm from './components/ProductForm';
import PrivateRoute from './components/PrivateRoute';
import Login from './components/Login';

const App = () => {
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated);

  return (
    <Router>
      <Navbar />
      <Switch>
        <Route exact path="/login" component={Login} />
        {/* PrivateRoute for authenticated users only */}
        <PrivateRoute exact path="/products" component={ProductList} />
        <PrivateRoute exact path="/add-product" component={ProductForm} />
        <Redirect from="/" to="/products" />
      </Switch>
    </Router>
  );
};

export default App;
